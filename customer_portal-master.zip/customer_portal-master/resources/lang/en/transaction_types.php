<?php
return [
    'debit' => 'Charge',
    'discount' => 'Credit',
    'payment' => 'Payment - Thank you!',
    'tax' => 'Tax (:type)',
];