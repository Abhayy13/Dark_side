<?php
return [
    'login' => 'Login',
    'makePayment' => 'Make Payment',
    'createTicket' => 'Create Ticket',
    'lookupEmail' => 'Look Up Email Address',
    'createAccount' => 'Create Account',
    'sendResetEmail' => 'Send Reset Email',
    'postReply' => 'Post a Reply',
    'delete' => 'Delete',
    'resetPassword' => 'Reset Password',
    'loginMessage' => 'Access your :ispName account',
    'linkMessage' => 'Link your :ispName account',
];