<?php
return [
    'username' => 'Username',
    'password' => 'Password',
    'register' => 'New portal user? Register an account here!',
    'forgot' => 'Forgot username or password?',
    'emailFound' => 'You will receive an email shortly with instructions on how to complete your account setup.',
    'resetSent' => 'You will receive an email shortly with instructions on how to reset your password.',
];