<?php
return [
    'logOut' => 'Log Out',
    'billing' => 'Billing',
    'myAccount' => 'MY ACCOUNT',
    'profile' => 'My Details',
    'tickets' => 'Support Tickets',
    'dataUsage' => 'Data Usage',
    'contracts' => 'Contracts',
    'myService'=>'MY SERVICE',
];