<?php
return [
    'date' => 'Date',
    'amount' => 'Amount',
    'accountNumber' => 'Account Number',
    'notAvailable' => 'Not Available',
    'yes' => 'Yes',
    'no' => 'No',
    'language' => 'Language',
];