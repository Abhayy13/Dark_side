<?php
return [
    'en' => 'English',
    'fr' => 'French',
];