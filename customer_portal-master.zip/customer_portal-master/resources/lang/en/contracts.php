<?php
return [
    'name' => 'Contract Name',
    'status' => 'Status',
    'action' => 'Action',
    'noContracts' => 'There are currently no contracts available.',
    'signed' => 'Signed',
    'pendingSignature' => 'Pending Signature',
    'sign' => 'Sign Contract',
    'download' => 'Download Contract',
];