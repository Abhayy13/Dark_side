<?php
return [
    'settingsAuth' => 'Settings Authentication',
    'authenticationKey' => 'Authentication Key',
];