<?php
return [
    'date' => 'Date',
    'amount' => 'Montant',
    'accountNumber' => 'Numéro de Compte',
    'notAvailable' => 'Non Disponible',
    'yes' => 'Oui',
    'no' => 'Non',
    'language' => 'Langue',
];