<?php
return [
    'login' => 'S\'identifier',
    'makePayment' => 'Faire un paiement',
    'createTicket' => 'Billet de Support',
    'lookupEmail' => 'Chercher un Courriel',
    'createAccount' => 'Crée un Compte',
    'sendResetEmail' => 'Réinisialiser Votre Mot de Passe',
    'postReply' => 'Afficher une Réponse',
    'delete' => 'Supprimer',
    'resetPassword' => 'Reinitialiser le mot de passe',
    'loginMessage' => 'Accédez à votre compte de :ispName',
    'linkMessage' => 'Liez votre compte :ispName',
];