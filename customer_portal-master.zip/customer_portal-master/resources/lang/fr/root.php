<?php
return [
    'username' => 'Nom d’utilisateur',
    'password' => 'Mot de passe',
    'register' => 'Nouvel utilisateur du portail? Créez un compte ici!',
    'forgot' => 'Nom d’utilisateur ou mot de passe oublié ?',
    'emailFound' => 'Vous recevrez un courriel sous peu avec des instructions sur la façon de terminer la configuration de votre compte.',
    'resetSent' => 'Vous recevrez un courriel sous peu avec des instructions sur la façon de réinitialiser votre mot de passe.',
];