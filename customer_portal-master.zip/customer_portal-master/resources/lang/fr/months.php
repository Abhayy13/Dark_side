<?php
return [
    '1' => 'Janv',
    '2' => 'Févr',
    '3' => 'Mars',
    '4' => 'Avril',
    '5' => 'Mai',
    '6' => 'Juin',
    '7' => 'Juil',
    '8' => 'Août',
    '9' => 'Sept',
    '10' => 'Oct',
    '11' => 'Nov',
    '12' => 'Déc',
];