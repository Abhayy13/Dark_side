<?php
return [
    'inbound' => 'Téléchargé',
    'outbound' => 'Téléchargé',
    'dailyUsage' => 'Utilisation Quotidienne',
    'usageHistory' => 'Utilisation Historique',
    'usage' => 'Usage',
    'purchaseAdditionalData' => 'Achete des données additionels',
    'quantity' => 'Quantité',
    'topOffExplanation' => 'Combien units additionel aimeriez vous achetez :Prix par :unitsGB?',
    'topOffTotal' => 'Votre limite va être augmenté  :countGB vous allez être chargé :prix',
    'confirmTopOffAddition' => 'Ajouter les données additionels et facturé mon compte',
    'successfullyAddedUsage' => ' Votre capacité pour cette periode de facturation a été augmenté!',
    'youMustHaveACardOnFile' => 'Vous devez avoir une carte de credit sur dossier pour acheter plus de données d\'usage. Ajouter une carte.',
	'monthlyGraphHeader' => 'Ce graphique montre votre utilisation mensuelle totale des douze périodes de facturation précédentes.',
];