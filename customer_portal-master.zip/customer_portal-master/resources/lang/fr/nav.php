<?php
return [
    'logOut' => 'Déconnexion',
    'billing' => 'Facturation',
    'myAccount' => 'MON COMPTE',
    'profile' => 'Mes coordonnées',
    'tickets' => 'Billets de support',
    'dataUsage' => 'Utilisation des données',
    'contracts' => 'Contrats',
    'myService' => 'MON SERVICE',
];