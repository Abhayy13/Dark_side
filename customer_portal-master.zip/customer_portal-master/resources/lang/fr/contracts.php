<?php
return [
    'name' => 'Nom de Contrat',
    'status' => 'Status',
    'action' => 'Action',
    'noContracts' => ' Présentement aucun contrat de disponible.',
    'signed' => 'Signé',
    'pendingSignature' => 'En Attente d\'une Signature.',
	'sign' => 'Signer un contrat',
    'download' => 'Télécharger le Contrat',
];