<?php
return [
    'debit' => 'Frais',
    'discount' => 'Crédit',
    'payment' => 'Paiement - Merci!',
    'tax' => 'Taxe (:type)',
];