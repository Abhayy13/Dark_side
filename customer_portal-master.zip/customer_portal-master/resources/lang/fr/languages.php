<?php
return [
    'en' => 'Anglais',
    'fr' => 'Français',
];