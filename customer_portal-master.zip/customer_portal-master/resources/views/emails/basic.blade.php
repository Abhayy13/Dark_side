<p>
    {{$greeting}}
</p>
<p>
    {!! $body !!}
</p>
<p>
    {{$deleteIfNotYou}}
</p>