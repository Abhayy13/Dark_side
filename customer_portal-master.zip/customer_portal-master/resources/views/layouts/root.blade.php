@include("layouts.partials.root-head")
@include('layouts.partials.success')
@include('layouts.partials.root-errors')
@yield('content')
@include('layouts.partials.js')
</html>