#!/bin/sh
exec /usr/sbin/php-fpm7.3 -F
